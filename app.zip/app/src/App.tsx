import { useState, useEffect, useCallback, useRef } from 'react';
import { AlertCircle } from 'lucide-react';
import { Header } from '@/components/Header';
import { TradingChart } from '@/components/chart/TradingChart';
import { SignalPanel } from '@/components/panels/SignalPanel';
import { AIAnalysisPanel } from '@/components/panels/AIAnalysisPanel';
import { CandleData, TradingSignal, AIAnalysisResult, TradingSymbol, TimeInterval } from '@/types/trading';
import { fetchTimeSeries } from '@/services/twelveDataService';
import { getAIAnalysis } from '@/services/openRouterService';
import { generateSignal } from '@/services/signalEngine';
import { API_CONFIG, isApiConfigured } from '@/config/api';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Toaster, toast } from 'sonner';

function App() {
  // State
  const [selectedSymbol, setSelectedSymbol] = useState<TradingSymbol>('XAU/USD');
  const [selectedInterval, setSelectedInterval] = useState<TimeInterval>('5min');
  const [candleData, setCandleData] = useState<CandleData[]>([]);
  const [signal, setSignal] = useState<TradingSignal | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState({ twelveData: false, openRouter: false });
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  
  // Refs for interval management
  const updateIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isMountedRef = useRef(true);

  // Check API status on mount
  useEffect(() => {
    const checkApis = async () => {
      const status = isApiConfigured();
      setApiStatus(status);
    };
    checkApis();
  }, []);

  // Fetch data function
  const fetchData = useCallback(async (showToast = false) => {
    if (!isMountedRef.current) return;
    
    const status = isApiConfigured();
    if (!status.twelveData) {
      setError('TwelveData API not configured. Please set your API key.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const data = await fetchTimeSeries(selectedSymbol, selectedInterval);
      
      if (!isMountedRef.current) return;
      
      setCandleData(data);
      setLastUpdate(new Date());
      
      // Generate signal from momentum engine
      const newSignal = generateSignal(data);
      setSignal(newSignal);
      
      if (showToast) {
        toast.success('Data updated successfully');
      }
    } catch (err) {
      if (!isMountedRef.current) return;
      
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch data';
      setError(errorMessage);
      
      if (showToast) {
        toast.error(errorMessage);
      }
    } finally {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }
  }, [selectedSymbol, selectedInterval]);

  // Fetch AI analysis
  const fetchAIAnalysis = useCallback(async () => {
    if (!isMountedRef.current) return;
    if (candleData.length < 20) return;
    
    const status = isApiConfigured();
    if (!status.openRouter) return; // Silently skip if not configured

    setIsAiLoading(true);
    setAiError(null);

    try {
      const analysis = await getAIAnalysis(candleData, selectedSymbol, selectedInterval);
      
      if (!isMountedRef.current) return;
      
      setAiAnalysis(analysis);
    } catch (err) {
      if (!isMountedRef.current) return;
      
      const errorMessage = err instanceof Error ? err.message : 'AI analysis failed';
      setAiError(errorMessage);
    } finally {
      if (isMountedRef.current) {
        setIsAiLoading(false);
      }
    }
  }, [candleData, selectedSymbol, selectedInterval]);

  // Initial data fetch
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Fetch AI analysis when data changes
  useEffect(() => {
    if (candleData.length >= 20) {
      fetchAIAnalysis();
    }
  }, [candleData, fetchAIAnalysis]);

  // Auto-update interval
  useEffect(() => {
    // Clear existing interval
    if (updateIntervalRef.current) {
      clearInterval(updateIntervalRef.current);
    }

    // Set new interval
    updateIntervalRef.current = setInterval(() => {
      fetchData();
    }, API_CONFIG.UPDATE_INTERVAL);

    return () => {
      if (updateIntervalRef.current) {
        clearInterval(updateIntervalRef.current);
      }
    };
  }, [fetchData]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      if (updateIntervalRef.current) {
        clearInterval(updateIntervalRef.current);
      }
    };
  }, []);

  // Handle manual refresh
  const handleRefresh = () => {
    fetchData(true);
  };

  // Handle symbol change
  const handleSymbolChange = (symbol: TradingSymbol) => {
    setSelectedSymbol(symbol);
    setCandleData([]);
    setSignal(null);
    setAiAnalysis(null);
  };

  // Handle interval change
  const handleIntervalChange = (interval: TimeInterval) => {
    setSelectedInterval(interval);
    setCandleData([]);
    setSignal(null);
    setAiAnalysis(null);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Toaster 
        position="top-right" 
        theme="dark"
        toastOptions={{
          style: {
            background: '#1f2937',
            border: '1px solid #374151',
            color: '#fff',
          },
        }}
      />
      
      <Header
        selectedSymbol={selectedSymbol}
        selectedInterval={selectedInterval}
        onSymbolChange={handleSymbolChange}
        onIntervalChange={handleIntervalChange}
        onRefresh={handleRefresh}
        isRefreshing={isLoading}
        apiStatus={apiStatus}
      />

      <main className="p-4">
        {/* Error Alert */}
        {error && (
          <Alert className="mb-4 bg-red-500/10 border-red-500/30">
            <AlertCircle className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-red-400">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Main Chart */}
        <div className="mb-4 h-[400px] sm:h-[500px] bg-gray-900/50 border border-gray-800 rounded-lg overflow-hidden">
          <TradingChart data={candleData} signal={signal} isLoading={isLoading} />
        </div>

        {/* Info Panels Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Signal Panel */}
          <SignalPanel signal={signal} isLoading={isLoading} />
          
          {/* AI Analysis Panel */}
          <AIAnalysisPanel 
            analysis={aiAnalysis} 
            isLoading={isAiLoading} 
            error={aiError}
          />
        </div>

        {/* Status Bar */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-xs text-gray-500">
          <div className="flex items-center gap-4">
            <span>
              Symbol: <span className="text-gray-300">{selectedSymbol}</span>
            </span>
            <span>
              Interval: <span className="text-gray-300">{selectedInterval}</span>
            </span>
          </div>
          <div className="flex items-center gap-4">
            {lastUpdate && (
              <span>
                Last Update: <span className="text-gray-300">{lastUpdate.toLocaleTimeString()}</span>
              </span>
            )}
            <span className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${isLoading ? 'bg-yellow-400 animate-pulse' : 'bg-green-400'}`} />
              {isLoading ? 'Updating...' : 'Live'}
            </span>
          </div>
        </div>

        {/* API Setup Notice */}
        {!apiStatus.allConfigured && (
          <div className="mt-4 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
            <h3 className="text-sm font-medium text-yellow-400 mb-2">API Configuration Required</h3>
            <p className="text-xs text-yellow-300/80 mb-3">
              To use this application, you need to configure API keys for TwelveData (market data) and OpenRouter (AI analysis).
            </p>
            <div className="space-y-2 text-xs">
              <p className="text-gray-400">Quick setup via browser console:</p>
              <code className="block p-2 bg-gray-800 rounded text-green-400 font-mono">
                localStorage.setItem('TWELVEDATA_API_KEY', 'your_twelvedata_api_key')<br/>
                localStorage.setItem('OPENROUTER_API_KEY', 'your_openrouter_api_key')<br/>
                location.reload()
              </code>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Get free API keys:{' '}
              <a href="https://twelvedata.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">twelvedata.com</a>
              {' '}and{' '}
              <a href="https://openrouter.ai" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">openrouter.ai</a>
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
