import type { CandleData, TradingSignal, SignalType, TrendType, MomentumAnalysis } from '@/types/trading';

// Calculate Simple Moving Average
const calculateSMA = (data: number[], period: number): number => {
  if (data.length < period) return 0;
  const sum = data.slice(-period).reduce((a, b) => a + b, 0);
  return sum / period;
};

// Calculate Average True Range (ATR)
const calculateATR = (candles: CandleData[], period: number = 14): number => {
  if (candles.length < period + 1) return 0;
  
  const trValues: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const current = candles[i];
    const previous = candles[i - 1];
    
    const tr1 = current.high - current.low;
    const tr2 = Math.abs(current.high - previous.close);
    const tr3 = Math.abs(current.low - previous.close);
    
    trValues.push(Math.max(tr1, tr2, tr3));
  }
  
  return calculateSMA(trValues, period);
};

// Calculate Average Volume
const calculateAvgVolume = (candles: CandleData[], period: number = 20): number => {
  if (candles.length < period) return 0;
  const volumes = candles.slice(-period).map(c => c.volume || 0);
  return calculateSMA(volumes, period);
};

// Analyze momentum of a single candle
const analyzeCandleMomentum = (
  current: CandleData,
  previous: CandleData,
  avgVolume: number
): MomentumAnalysis => {
  const range = current.high - current.low;
  const bodySize = Math.abs(current.close - current.open);
  const bodyPercent = range > 0 ? (bodySize / range) * 100 : 0;
  
  const isBullish = current.close > current.open;
  const isBearish = current.close < current.open;
  
  const volumeIncrease = (current.volume || 0) > avgVolume * 1.2;
  const breaksHigh = current.high > previous.high;
  const breaksLow = current.low < previous.low;
  
  // Sideway detection: small body and overlapping range
  const isSideway = bodyPercent < 40 || (bodySize < range * 0.3);
  
  return {
    bodySize,
    bodyPercent,
    range,
    isBullish,
    isBearish,
    volumeIncrease,
    breaksHigh,
    breaksLow,
    isSideway,
  };
};

// Detect trend direction
const detectTrend = (candles: CandleData[]): TrendType => {
  if (candles.length < 20) return 'Sideways';
  
  const closes = candles.map(c => c.close);
  const sma20 = calculateSMA(closes, 20);
  const sma10 = calculateSMA(closes, 10);
  const sma5 = calculateSMA(closes, 5);
  
  const lastPrice = closes[closes.length - 1];
  
  // Strong uptrend
  if (sma5 > sma10 && sma10 > sma20 && lastPrice > sma5) {
    return 'Bullish';
  }
  
  // Strong downtrend
  if (sma5 < sma10 && sma10 < sma20 && lastPrice < sma5) {
    return 'Bearish';
  }
  
  // Check price position relative to SMA20
  if (lastPrice > sma20 * 1.01) return 'Bullish';
  if (lastPrice < sma20 * 0.99) return 'Bearish';
  
  return 'Sideways';
};

// Calculate confidence score (0-100)
const calculateConfidence = (
  signal: SignalType,
  momentum: MomentumAnalysis,
  trend: TrendType
): number => {
  let confidence = 50;
  
  if (signal === 'BUY') {
    // Body size factor
    if (momentum.bodyPercent >= 80) confidence += 15;
    else if (momentum.bodyPercent >= 70) confidence += 10;
    else if (momentum.bodyPercent >= 60) confidence += 5;
    
    // Volume factor
    if (momentum.volumeIncrease) confidence += 15;
    
    // Breakout factor
    if (momentum.breaksHigh) confidence += 10;
    
    // Trend alignment
    if (trend === 'Bullish') confidence += 10;
    
  } else if (signal === 'SELL') {
    // Body size factor
    if (momentum.bodyPercent >= 80) confidence += 15;
    else if (momentum.bodyPercent >= 70) confidence += 10;
    else if (momentum.bodyPercent >= 60) confidence += 5;
    
    // Volume factor
    if (momentum.volumeIncrease) confidence += 15;
    
    // Breakdown factor
    if (momentum.breaksLow) confidence += 10;
    
    // Trend alignment
    if (trend === 'Bearish') confidence += 10;
    
  } else {
    // WAIT signal confidence
    if (momentum.isSideway) confidence += 20;
    if (trend === 'Sideways') confidence += 15;
    if (!momentum.volumeIncrease) confidence += 10;
  }
  
  return Math.min(100, Math.max(0, confidence));
};

// Calculate entry, stop loss, and take profit levels
const calculateTradingLevels = (
  signal: SignalType,
  candles: CandleData[]
): { entry: number | null; stopLoss: number | null; takeProfit: number | null } => {
  if (candles.length < 2) {
    return { entry: null, stopLoss: null, takeProfit: null };
  }
  
  const lastCandle = candles[candles.length - 1];
  const atr = calculateATR(candles, 14);
  
  if (signal === 'BUY') {
    // Entry at close of momentum candle
    const entry = lastCandle.close;
    // Stop loss below the low of momentum candle or ATR-based
    const stopLoss = Math.min(lastCandle.low, entry - atr * 1.5);
    // Take profit with 1:2 risk-reward ratio
    const risk = entry - stopLoss;
    const takeProfit = entry + risk * 2;
    
    return { entry, stopLoss, takeProfit };
  } 
  
  if (signal === 'SELL') {
    // Entry at close of momentum candle
    const entry = lastCandle.close;
    // Stop loss above the high of momentum candle or ATR-based
    const stopLoss = Math.max(lastCandle.high, entry + atr * 1.5);
    // Take profit with 1:2 risk-reward ratio
    const risk = stopLoss - entry;
    const takeProfit = entry - risk * 2;
    
    return { entry, stopLoss, takeProfit };
  }
  
  // WAIT signal - no trading levels
  return { entry: null, stopLoss: null, takeProfit: null };
};

// Main signal generation function
export const generateSignal = (candles: CandleData[]): TradingSignal => {
  // Minimum data check
  if (candles.length < 5) {
    return {
      signal: 'WAIT',
      confidence: 0,
      trend: 'Sideways',
      entryPrice: null,
      stopLoss: null,
      takeProfit: null,
      timestamp: Date.now(),
    };
  }
  
  const current = candles[candles.length - 1];
  const previous = candles[candles.length - 2];
  const avgVolume = calculateAvgVolume(candles, 20);
  
  // Analyze momentum
  const momentum = analyzeCandleMomentum(current, previous, avgVolume);
  
  // Detect trend
  const trend = detectTrend(candles);
  
  // Determine signal based on momentum criteria
  let signal: SignalType = 'WAIT';
  
  // BUY Criteria:
  // - Bullish candle
  // - Body >= 70% of range
  // - Breaks previous high
  // - Volume increase (optional but strengthens signal)
  if (
    momentum.isBullish &&
    momentum.bodyPercent >= 70 &&
    momentum.breaksHigh
  ) {
    signal = 'BUY';
  }
  // SELL Criteria:
  // - Bearish candle
  // - Body >= 70% of range
  // - Breaks previous low
  // - Volume increase (optional but strengthens signal)
  else if (
    momentum.isBearish &&
    momentum.bodyPercent >= 70 &&
    momentum.breaksLow
  ) {
    signal = 'SELL';
  }
  // WAIT: Sideway market or weak momentum
  else if (momentum.isSideway || momentum.bodyPercent < 50) {
    signal = 'WAIT';
  }
  // Default to WAIT if no clear signal
  else {
    signal = 'WAIT';
  }
  
  // Calculate confidence
  const confidence = calculateConfidence(signal, momentum, trend);
  
  // Calculate trading levels
  const { entry, stopLoss, takeProfit } = calculateTradingLevels(signal, candles);
  
  return {
    signal,
    confidence,
    trend,
    entryPrice: entry,
    stopLoss,
    takeProfit,
    timestamp: Date.now(),
  };
};

// Get signal description
export const getSignalDescription = (signal: SignalType): string => {
  switch (signal) {
    case 'BUY':
      return 'Strong bullish momentum detected. Large body candle breaking previous high with volume confirmation.';
    case 'SELL':
      return 'Strong bearish momentum detected. Large body candle breaking previous low with volume confirmation.';
    case 'WAIT':
      return 'Market showing sideways movement or weak momentum. Wait for clearer signal.';
    default:
      return 'Analyzing market conditions...';
  }
};

// Export helper functions for testing
export const SignalEngineHelpers = {
  calculateSMA,
  calculateATR,
  calculateAvgVolume,
  analyzeCandleMomentum,
  detectTrend,
  calculateConfidence,
  calculateTradingLevels,
};
