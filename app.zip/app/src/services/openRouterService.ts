import axios from 'axios';
import { API_CONFIG } from '@/config/api';
import type { CandleData, AIAnalysisResult, SignalType, TrendType } from '@/types/trading';

// Get API key from localStorage or config
const getApiKey = (): string => {
  const fromStorage = localStorage.getItem('OPENROUTER_API_KEY');
  if (fromStorage && fromStorage.length > 10) return fromStorage;
  return API_CONFIG.OPENROUTER.API_KEY;
};

// Calculate technical indicators for AI context
const calculateIndicators = (candles: CandleData[]) => {
  if (candles.length < 20) return null;
  
  const closes = candles.map(c => c.close);
  const volumes = candles.map(c => c.volume || 0);
  
  // Simple Moving Average
  const sma20 = closes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const sma10 = closes.slice(-10).reduce((a, b) => a + b, 0) / 10;
  const sma5 = closes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  
  // Average Volume
  const avgVolume = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const lastVolume = volumes[volumes.length - 1];
  
  // Price change
  const priceChange = ((closes[closes.length - 1] - closes[closes.length - 2]) / closes[closes.length - 2]) * 100;
  
  // High/Low ranges
  const lastCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2];
  
  return {
    sma20,
    sma10,
    sma5,
    avgVolume,
    lastVolume,
    priceChange,
    lastCandle,
    prevCandle,
    highestHigh: Math.max(...candles.slice(-20).map(c => c.high)),
    lowestLow: Math.min(...candles.slice(-20).map(c => c.low)),
  };
};

// Generate AI analysis prompt
const generatePrompt = (candles: CandleData[], symbol: string, interval: string): string => {
  const indicators = calculateIndicators(candles);
  if (!indicators) return '';
  
  const { lastCandle, prevCandle, sma20, sma10, sma5, avgVolume, lastVolume, priceChange, highestHigh, lowestLow } = indicators;
  
  const bodySize = Math.abs(lastCandle.close - lastCandle.open);
  const range = lastCandle.high - lastCandle.low;
  const bodyPercent = range > 0 ? (bodySize / range) * 100 : 0;
  const isBullish = lastCandle.close > lastCandle.open;
  const volumeIncrease = lastVolume > avgVolume * 1.2;
  
  return `Analyze this trading data for ${symbol} on ${interval} timeframe:

RECENT PRICE DATA (Last 5 candles):
${candles.slice(-5).map((c, i) => 
  `Candle ${i + 1}: O=${c.open.toFixed(4)} H=${c.high.toFixed(4)} L=${c.low.toFixed(4)} C=${c.close.toFixed(4)} V=${(c.volume || 0).toFixed(0)}`
).join('\n')}

TECHNICAL INDICATORS:
- SMA 5: ${sma5.toFixed(4)}
- SMA 10: ${sma10.toFixed(4)}
- SMA 20: ${sma20.toFixed(4)}
- 20-Period High: ${highestHigh.toFixed(4)}
- 20-Period Low: ${lowestLow.toFixed(4)}
- Average Volume: ${avgVolume.toFixed(0)}
- Last Volume: ${lastVolume.toFixed(0)}
- Volume Increased: ${volumeIncrease ? 'Yes' : 'No'}
- Price Change: ${priceChange.toFixed(2)}%

LAST CANDLE ANALYSIS:
- Body Size: ${bodySize.toFixed(4)} (${bodyPercent.toFixed(1)}% of range)
- Direction: ${isBullish ? 'Bullish' : 'Bearish'}
- Breaks Previous High: ${lastCandle.high > prevCandle.high ? 'Yes' : 'No'}
- Breaks Previous Low: ${lastCandle.low < prevCandle.low ? 'Yes' : 'No'}

Based on momentum candle strategy:
- BUY: Large bullish candle (body >70% of range), breaks previous high, volume increase
- SELL: Large bearish candle (body >70% of range), breaks previous low, volume increase  
- WAIT: Small candles, sideways movement, no clear momentum

Provide analysis in this exact format:
Signal: [BUY/SELL/WAIT]
Confidence: [0-100]%
Trend: [Bullish/Bearish/Sideways]
Reason: [2-3 sentences explaining the signal]
Support: [price level]
Resistance: [price level]
Recommendation: [1 sentence trading advice]`;
};

// Parse AI response
const parseAIResponse = (response: string): AIAnalysisResult => {
  const lines = response.split('\n').map(l => l.trim()).filter(l => l);
  
  let signal: SignalType = 'WAIT';
  let confidence = 50;
  let trend: TrendType = 'Sideways';
  let reason = 'Analysis pending';
  let support = 0;
  let resistance = 0;
  let recommendation = 'Wait for clearer signal';
  
  for (const line of lines) {
    if (line.toLowerCase().startsWith('signal:')) {
      const val = line.split(':')[1]?.trim().toUpperCase();
      if (val === 'BUY' || val === 'SELL' || val === 'WAIT') {
        signal = val;
      }
    } else if (line.toLowerCase().startsWith('confidence:')) {
      const val = parseInt(line.split(':')[1]?.trim() || '50');
      confidence = isNaN(val) ? 50 : Math.min(100, Math.max(0, val));
    } else if (line.toLowerCase().startsWith('trend:')) {
      const val = line.split(':')[1]?.trim();
      if (val?.toLowerCase().includes('bull')) trend = 'Bullish';
      else if (val?.toLowerCase().includes('bear')) trend = 'Bearish';
      else trend = 'Sideways';
    } else if (line.toLowerCase().startsWith('reason:')) {
      reason = line.split(':').slice(1).join(':').trim();
    } else if (line.toLowerCase().startsWith('support:')) {
      support = parseFloat(line.split(':')[1]?.trim() || '0');
    } else if (line.toLowerCase().startsWith('resistance:')) {
      resistance = parseFloat(line.split(':')[1]?.trim() || '0');
    } else if (line.toLowerCase().startsWith('recommendation:')) {
      recommendation = line.split(':').slice(1).join(':').trim();
    }
  }
  
  return {
    signal,
    confidence,
    trend,
    reason: reason || 'Analysis completed',
    keyLevels: { support: support || 0, resistance: resistance || 0 },
    recommendation: recommendation || 'Monitor market conditions',
  };
};

// Get AI analysis
export const getAIAnalysis = async (
  candles: CandleData[],
  symbol: string,
  interval: string
): Promise<AIAnalysisResult> => {
  const apiKey = getApiKey();
  
  if (!apiKey || apiKey === 'MASUKKAN_API_KEY_OPENROUTER_ANDA_DI_SINI') {
    throw new Error('OpenRouter API Key not configured. Please set your API key in src/config/api.ts or localStorage.');
  }
  
  if (candles.length < 20) {
    throw new Error('Insufficient data for analysis. Need at least 20 candles.');
  }
  
  const prompt = generatePrompt(candles, symbol, interval);
  
  try {
    const response = await axios.post(
      `${API_CONFIG.OPENROUTER.BASE_URL}/chat/completions`,
      {
        model: API_CONFIG.OPENROUTER.MODEL,
        messages: [
          {
            role: 'system',
            content: 'You are a professional trading analyst specializing in momentum candle strategies. Provide concise, accurate technical analysis based on price action and volume. Always respond in the exact format requested.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 500,
        temperature: 0.3,
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': window.location.origin,
          'X-Title': 'Momentum Trading Pro',
        },
        timeout: 30000,
      }
    );
    
    const aiResponse = response.data.choices?.[0]?.message?.content;
    if (!aiResponse) {
      throw new Error('Empty response from AI');
    }
    
    return parseAIResponse(aiResponse);
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response?.status === 401) {
        throw new Error('Invalid OpenRouter API Key. Please check your API key.');
      }
      if (error.response?.status === 429) {
        throw new Error('AI API rate limit exceeded. Please wait a moment.');
      }
      throw new Error(error.response?.data?.error?.message || error.message);
    }
    throw error;
  }
};

// Check if API is available
export const checkOpenRouterApi = async (): Promise<boolean> => {
  try {
    const apiKey = getApiKey();
    if (!apiKey || apiKey === 'MASUKKAN_API_KEY_OPENROUTER_ANDA_DI_SINI') {
      return false;
    }
    
    // Simple validation request
    await axios.get(`${API_CONFIG.OPENROUTER.BASE_URL}/models`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
      },
      timeout: 5000,
    });
    return true;
  } catch {
    return false;
  }
};
