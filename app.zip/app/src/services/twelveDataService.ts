import axios from 'axios';
import { API_CONFIG } from '@/config/api';
import type { CandleData, TwelveDataResponse, TimeInterval, TradingSymbol } from '@/types/trading';

// Get API key from localStorage or config
const getApiKey = (): string => {
  const fromStorage = localStorage.getItem('TWELVEDATA_API_KEY');
  if (fromStorage && fromStorage.length > 10) return fromStorage;
  return API_CONFIG.TWELVEDATA.API_KEY;
};

// Convert TwelveData format to Lightweight Charts format
const convertCandleData = (data: TwelveDataResponse): CandleData[] => {
  if (!data.values || !Array.isArray(data.values)) {
    throw new Error('Invalid data format from TwelveData');
  }
  
  return data.values
    .map((candle) => ({
      time: new Date(candle.datetime).getTime() / 1000,
      open: parseFloat(candle.open),
      high: parseFloat(candle.high),
      low: parseFloat(candle.low),
      close: parseFloat(candle.close),
      volume: parseFloat(candle.volume) || 0,
    }))
    .sort((a, b) => a.time - b.time); // Sort by time ascending
};

// Fetch time series data from TwelveData
export const fetchTimeSeries = async (
  symbol: TradingSymbol,
  interval: TimeInterval,
  outputsize: number = API_CONFIG.CHART.DEFAULT_OUTPUT_SIZE
): Promise<CandleData[]> => {
  const apiKey = getApiKey();
  
  if (!apiKey || apiKey === 'MASUKKAN_API_KEY_TWELVEDATA_ANDA_DI_SINI') {
    throw new Error('TwelveData API Key not configured. Please set your API key in src/config/api.ts or localStorage.');
  }
  
  try {
    const response = await axios.get<TwelveDataResponse>(
      `${API_CONFIG.TWELVEDATA.BASE_URL}/time_series`,
      {
        params: {
          symbol,
          interval,
          outputsize,
          apikey: apiKey,
        },
        timeout: 10000,
      }
    );
    
    if (response.data.status === 'error') {
      throw new Error('API Error: ' + ((response.data as unknown as { message?: string }).message || 'Unknown error'));
    }
    
    return convertCandleData(response.data);
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response?.status === 401) {
        throw new Error('Invalid TwelveData API Key. Please check your API key.');
      }
      if (error.response?.status === 429) {
        throw new Error('API rate limit exceeded. Please wait a moment.');
      }
      throw new Error(error.response?.data?.message || error.message);
    }
    throw error;
  }
};

// Fetch latest price quote
export const fetchQuote = async (symbol: TradingSymbol): Promise<{ price: number; change: number; changePercent: number }> => {
  const apiKey = getApiKey();
  
  if (!apiKey || apiKey === 'MASUKKAN_API_KEY_TWELVEDATA_ANDA_DI_SINI') {
    throw new Error('TwelveData API Key not configured');
  }
  
  try {
    const response = await axios.get(
      `${API_CONFIG.TWELVEDATA.BASE_URL}/quote`,
      {
        params: {
          symbol,
          apikey: apiKey,
        },
        timeout: 10000,
      }
    );
    
    return {
      price: parseFloat(response.data.close),
      change: parseFloat(response.data.change),
      changePercent: parseFloat(response.data.percent_change),
    };
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || error.message);
    }
    throw error;
  }
};

// Check if API is available
export const checkTwelveDataApi = async (): Promise<boolean> => {
  try {
    const apiKey = getApiKey();
    if (!apiKey || apiKey === 'MASUKKAN_API_KEY_TWELVEDATA_ANDA_DI_SINI') {
      return false;
    }
    
    // Try to fetch a simple quote
    await axios.get(
      `${API_CONFIG.TWELVEDATA.BASE_URL}/quote`,
      {
        params: {
          symbol: 'AAPL',
          apikey: apiKey,
        },
        timeout: 5000,
      }
    );
    return true;
  } catch {
    return false;
  }
};
