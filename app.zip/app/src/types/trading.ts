// Trading Types and Interfaces

export interface CandleData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface TwelveDataCandle {
  datetime: string;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
}

export interface TwelveDataResponse {
  meta: {
    symbol: string;
    interval: string;
    currency: string;
    exchange: string;
    type: string;
  };
  values: TwelveDataCandle[];
  status: string;
}

export type SignalType = 'BUY' | 'SELL' | 'WAIT';
export type TrendType = 'Bullish' | 'Bearish' | 'Sideways';

export interface TradingSignal {
  signal: SignalType;
  confidence: number;
  trend: TrendType;
  entryPrice: number | null;
  stopLoss: number | null;
  takeProfit: number | null;
  timestamp: number;
}

export interface MomentumAnalysis {
  bodySize: number;
  bodyPercent: number;
  range: number;
  isBullish: boolean;
  isBearish: boolean;
  volumeIncrease: boolean;
  breaksHigh: boolean;
  breaksLow: boolean;
  isSideway: boolean;
}

export interface AIAnalysisResult {
  signal: SignalType;
  reason: string;
  trend: TrendType;
  confidence: number;
  keyLevels: {
    support: number;
    resistance: number;
  };
  recommendation: string;
}

export type TimeInterval = '1min' | '3min' | '5min' | '15min';

export type TradingSymbol = 'XAU/USD' | 'BTC/USD' | 'EUR/USD';

export interface SymbolConfig {
  symbol: TradingSymbol;
  label: string;
  category: 'commodity' | 'crypto' | 'forex';
}

export const SYMBOLS: SymbolConfig[] = [
  { symbol: 'XAU/USD', label: 'GOLD', category: 'commodity' },
  { symbol: 'BTC/USD', label: 'BTC', category: 'crypto' },
  { symbol: 'EUR/USD', label: 'EURUSD', category: 'forex' },
];

export const INTERVALS: { value: TimeInterval; label: string }[] = [
  { value: '1min', label: '1M' },
  { value: '3min', label: '3M' },
  { value: '5min', label: '5M' },
  { value: '15min', label: '15M' },
];
