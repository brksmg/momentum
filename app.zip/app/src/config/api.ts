// API Configuration
// GANTI API KEY DI BAWAH INI DENGAN API KEY ANDA

export const API_CONFIG = {
  // OpenRouter API Configuration
  OPENROUTER: {
    API_KEY: 'MASUKKAN_API_KEY_OPENROUTER_ANDA_DI_SINI',
    BASE_URL: 'https://openrouter.ai/api/v1',
    MODEL: 'openai/gpt-4o-mini',
    // Alternative models:
    // MODEL: 'anthropic/claude-3-haiku',
    // MODEL: 'google/gemini-2.0-flash-001',
  },
  
  // TwelveData API Configuration
  TWELVEDATA: {
    API_KEY: 'MASUKKAN_API_KEY_TWELVEDATA_ANDA_DI_SINI',
    BASE_URL: 'https://api.twelvedata.com',
  },
  
  // Update interval in milliseconds (3-5 seconds)
  UPDATE_INTERVAL: 5000,
  
  // Chart settings
  CHART: {
    DEFAULT_OUTPUT_SIZE: 200,
    MIN_CANDLES_FOR_ANALYSIS: 20,
  },
};

// Helper to check if API keys are configured
export const isApiConfigured = () => {
  const openRouterConfigured = API_CONFIG.OPENROUTER.API_KEY !== 'MASUKKAN_API_KEY_OPENROUTER_ANDA_DI_SINI' && 
                                API_CONFIG.OPENROUTER.API_KEY.length > 10;
  const twelveDataConfigured = API_CONFIG.TWELVEDATA.API_KEY !== 'MASUKKAN_API_KEY_TWELVEDATA_ANDA_DI_SINI' && 
                               API_CONFIG.TWELVEDATA.API_KEY.length > 10;
  
  return {
    openRouter: openRouterConfigured,
    twelveData: twelveDataConfigured,
    allConfigured: openRouterConfigured && twelveDataConfigured,
  };
};

// Instructions for users
export const API_SETUP_INSTRUCTIONS = `
UNTUK MENGGUNAKAN APLIKASI INI:

1. Daftar di TwelveData (https://twelvedata.com) untuk mendapatkan API Key gratis
2. Daftar di OpenRouter (https://openrouter.ai) untuk mendapatkan API Key gratis
3. Edit file src/config/api.ts dan ganti API_KEY dengan key Anda
4. Rebuild aplikasi dengan perintah: npm run build

ATAU

Anda bisa set API key via localStorage di browser:
- Buka Developer Tools (F12)
- Buka Console
- Ketik:
  localStorage.setItem('TWELVEDATA_API_KEY', 'api_key_anda')
  localStorage.setItem('OPENROUTER_API_KEY', 'api_key_anda')
  location.reload()
`;
