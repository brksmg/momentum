import { Brain, TrendingUp, TrendingDown, Minus, AlertCircle, Lightbulb } from 'lucide-react';
import { AIAnalysisResult, SignalType } from '@/types/trading';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface AIAnalysisPanelProps {
  analysis: AIAnalysisResult | null;
  isLoading?: boolean;
  error?: string | null;
}

const getSignalBadge = (signal: SignalType) => {
  switch (signal) {
    case 'BUY':
      return (
        <Badge className="bg-green-500/20 text-green-400 border-green-500/30 hover:bg-green-500/30">
          <TrendingUp className="w-3 h-3 mr-1" />
          BUY
        </Badge>
      );
    case 'SELL':
      return (
        <Badge className="bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30">
          <TrendingDown className="w-3 h-3 mr-1" />
          SELL
        </Badge>
      );
    case 'WAIT':
      return (
        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 hover:bg-yellow-500/30">
          <Minus className="w-3 h-3 mr-1" />
          WAIT
        </Badge>
      );
  }
};

const getTrendBadge = (trend: string) => {
  switch (trend.toLowerCase()) {
    case 'bullish':
      return <span className="text-green-400 font-medium">Bullish</span>;
    case 'bearish':
      return <span className="text-red-400 font-medium">Bearish</span>;
    default:
      return <span className="text-yellow-400 font-medium">Sideways</span>;
  }
};

export function AIAnalysisPanel({ analysis, isLoading, error }: AIAnalysisPanelProps) {
  if (isLoading) {
    return (
      <Card className="bg-gray-900/80 border-gray-800 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-purple-400" />
          <h3 className="font-semibold text-gray-200">AI Analysis</h3>
        </div>
        <div className="flex items-center justify-center h-32">
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Brain className="w-3 h-3 text-purple-400" />
              </div>
            </div>
            <span className="text-sm text-gray-400">AI analyzing market data...</span>
          </div>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-gray-900/80 border-gray-800 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-purple-400" />
          <h3 className="font-semibold text-gray-200">AI Analysis</h3>
        </div>
        <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
          <div>
            <p className="text-sm text-red-400 font-medium">Analysis Error</p>
            <p className="text-xs text-red-300/70">{error}</p>
          </div>
        </div>
      </Card>
    );
  }

  if (!analysis) {
    return (
      <Card className="bg-gray-900/80 border-gray-800 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-purple-400" />
          <h3 className="font-semibold text-gray-200">AI Analysis</h3>
        </div>
        <div className="flex items-center justify-center h-32 text-gray-500">
          <p className="text-sm">AI analysis will appear here</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-gray-900/80 border-gray-800 p-4">
      <div className="flex items-center gap-2 mb-4">
        <Brain className="w-5 h-5 text-purple-400" />
        <h3 className="font-semibold text-gray-200">AI Analysis</h3>
        <div className="ml-auto">
          {getSignalBadge(analysis.signal)}
        </div>
      </div>

      <div className="space-y-4">
        {/* AI Reason */}
        <div className="p-3 bg-gray-800/50 rounded-lg">
          <p className="text-sm text-gray-300 leading-relaxed">{analysis.reason}</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-2 bg-gray-800/30 rounded-lg">
            <span className="text-xs text-gray-500 block mb-1">Trend</span>
            {getTrendBadge(analysis.trend)}
          </div>
          <div className="p-2 bg-gray-800/30 rounded-lg">
            <span className="text-xs text-gray-500 block mb-1">Confidence</span>
            <span className={`font-medium ${
              analysis.confidence >= 80 ? 'text-green-400' :
              analysis.confidence >= 60 ? 'text-blue-400' :
              analysis.confidence >= 40 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {analysis.confidence}%
            </span>
          </div>
        </div>

        {/* Key Levels */}
        {(analysis.keyLevels.support > 0 || analysis.keyLevels.resistance > 0) && (
          <div className="grid grid-cols-2 gap-3">
            <div className="p-2 bg-green-500/10 border border-green-500/20 rounded-lg">
              <span className="text-xs text-green-500/70 block mb-1">Support</span>
              <span className="font-mono text-sm text-green-400">
                {analysis.keyLevels.support > 0 ? analysis.keyLevels.support.toFixed(4) : '-'}
              </span>
            </div>
            <div className="p-2 bg-red-500/10 border border-red-500/20 rounded-lg">
              <span className="text-xs text-red-500/70 block mb-1">Resistance</span>
              <span className="font-mono text-sm text-red-400">
                {analysis.keyLevels.resistance > 0 ? analysis.keyLevels.resistance.toFixed(4) : '-'}
              </span>
            </div>
          </div>
        )}

        {/* Recommendation */}
        <div className="flex items-start gap-2 p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg">
          <Lightbulb className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
          <div>
            <span className="text-xs text-purple-400/70 block mb-1">AI Recommendation</span>
            <p className="text-sm text-purple-200">{analysis.recommendation}</p>
          </div>
        </div>
      </div>
    </Card>
  );
}
