import { TrendingUp, TrendingDown, Minus, Activity, Target, Shield } from 'lucide-react';
import { TradingSignal, SignalType, TrendType } from '@/types/trading';
import { Card } from '@/components/ui/card';

interface SignalPanelProps {
  signal: TradingSignal | null;
  isLoading?: boolean;
}

const getSignalColor = (signal: SignalType): string => {
  switch (signal) {
    case 'BUY':
      return 'text-green-500 bg-green-500/10 border-green-500/30';
    case 'SELL':
      return 'text-red-500 bg-red-500/10 border-red-500/30';
    case 'WAIT':
      return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/30';
    default:
      return 'text-gray-500 bg-gray-500/10 border-gray-500/30';
  }
};

const getSignalIcon = (signal: SignalType) => {
  switch (signal) {
    case 'BUY':
      return <TrendingUp className="w-8 h-8" />;
    case 'SELL':
      return <TrendingDown className="w-8 h-8" />;
    case 'WAIT':
      return <Minus className="w-8 h-8" />;
    default:
      return <Activity className="w-8 h-8" />;
  }
};

const getTrendColor = (trend: TrendType): string => {
  switch (trend) {
    case 'Bullish':
      return 'text-green-400';
    case 'Bearish':
      return 'text-red-400';
    case 'Sideways':
      return 'text-yellow-400';
    default:
      return 'text-gray-400';
  }
};

const getTrendIcon = (trend: TrendType) => {
  switch (trend) {
    case 'Bullish':
      return <TrendingUp className="w-4 h-4" />;
    case 'Bearish':
      return <TrendingDown className="w-4 h-4" />;
    case 'Sideways':
      return <Minus className="w-4 h-4" />;
    default:
      return <Activity className="w-4 h-4" />;
  }
};

const getConfidenceColor = (confidence: number): string => {
  if (confidence >= 80) return 'text-green-400';
  if (confidence >= 60) return 'text-blue-400';
  if (confidence >= 40) return 'text-yellow-400';
  return 'text-red-400';
};

export function SignalPanel({ signal, isLoading }: SignalPanelProps) {
  if (isLoading) {
    return (
      <Card className="bg-gray-900/80 border-gray-800 p-4">
        <div className="flex items-center justify-center h-32">
          <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </Card>
    );
  }

  if (!signal) {
    return (
      <Card className="bg-gray-900/80 border-gray-800 p-4">
        <div className="flex items-center justify-center h-32 text-gray-500">
          <p>Waiting for signal...</p>
        </div>
      </Card>
    );
  }

  const signalColorClass = getSignalColor(signal.signal);
  const trendColorClass = getTrendColor(signal.trend);
  const confidenceColorClass = getConfidenceColor(signal.confidence);

  return (
    <Card className="bg-gray-900/80 border-gray-800 overflow-hidden">
      {/* Signal Header */}
      <div className={`p-4 border-b ${signalColorClass.split(' ')[2]}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${signalColorClass.split(' ').slice(1).join(' ')}`}>
              {getSignalIcon(signal.signal)}
            </div>
            <div>
              <p className="text-xs text-gray-400 uppercase tracking-wider">Current Signal</p>
              <h2 className={`text-2xl font-bold ${signalColorClass.split(' ')[0]}`}>
                {signal.signal}
              </h2>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400 uppercase tracking-wider">Confidence</p>
            <p className={`text-2xl font-bold ${confidenceColorClass}`}>
              {signal.confidence}%
            </p>
          </div>
        </div>
      </div>

      {/* Signal Details */}
      <div className="p-4 space-y-4">
        {/* Trend */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-400">Market Trend</span>
          <div className={`flex items-center gap-2 ${trendColorClass}`}>
            {getTrendIcon(signal.trend)}
            <span className="font-medium">{signal.trend}</span>
          </div>
        </div>

        {/* Confidence Bar */}
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-gray-500">Signal Strength</span>
            <span className={confidenceColorClass}>{signal.confidence}%</span>
          </div>
          <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                signal.confidence >= 80
                  ? 'bg-green-500'
                  : signal.confidence >= 60
                  ? 'bg-blue-500'
                  : signal.confidence >= 40
                  ? 'bg-yellow-500'
                  : 'bg-red-500'
              }`}
              style={{ width: `${signal.confidence}%` }}
            />
          </div>
        </div>

        {/* Trading Levels */}
        {signal.signal !== 'WAIT' && signal.entryPrice && (
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-gray-800">
            <div className="text-center p-2 bg-gray-800/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Target className="w-3 h-3 text-blue-400" />
                <span className="text-xs text-gray-500">Entry</span>
              </div>
              <p className="text-sm font-mono font-medium text-blue-400">
                {signal.entryPrice.toFixed(4)}
              </p>
            </div>
            <div className="text-center p-2 bg-gray-800/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Shield className="w-3 h-3 text-red-400" />
                <span className="text-xs text-gray-500">SL</span>
              </div>
              <p className="text-sm font-mono font-medium text-red-400">
                {signal.stopLoss?.toFixed(4) || '-'}
              </p>
            </div>
            <div className="text-center p-2 bg-gray-800/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Target className="w-3 h-3 text-green-400" />
                <span className="text-xs text-gray-500">TP</span>
              </div>
              <p className="text-sm font-mono font-medium text-green-400">
                {signal.takeProfit?.toFixed(4) || '-'}
              </p>
            </div>
          </div>
        )}

        {/* Risk/Reward Ratio */}
        {signal.signal !== 'WAIT' && signal.entryPrice && signal.stopLoss && signal.takeProfit && (
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-500">Risk/Reward Ratio</span>
            <span className="text-gray-300">
              1:{((Math.abs(signal.takeProfit - signal.entryPrice) / Math.abs(signal.stopLoss - signal.entryPrice))).toFixed(1)}
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}
