import { BarChart3, Settings, RefreshCw, AlertTriangle } from 'lucide-react';
import { TradingSymbol, TimeInterval, SYMBOLS, INTERVALS } from '@/types/trading';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  selectedSymbol: TradingSymbol;
  selectedInterval: TimeInterval;
  onSymbolChange: (symbol: TradingSymbol) => void;
  onIntervalChange: (interval: TimeInterval) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  apiStatus: {
    twelveData: boolean;
    openRouter: boolean;
  };
}

export function Header({
  selectedSymbol,
  selectedInterval,
  onSymbolChange,
  onIntervalChange,
  onRefresh,
  isRefreshing,
  apiStatus,
}: HeaderProps) {
  const allApisConnected = apiStatus.twelveData && apiStatus.openRouter;

  return (
    <header className="bg-gray-900/95 border-b border-gray-800 sticky top-0 z-50 backdrop-blur-sm">
      <div className="px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-white">Momentum Pro</h1>
              <p className="text-xs text-gray-500">Trading Analysis</p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Symbol Selector */}
            <Select value={selectedSymbol} onValueChange={(v) => onSymbolChange(v as TradingSymbol)}>
              <SelectTrigger className="w-[100px] sm:w-[120px] bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Symbol" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                {SYMBOLS.map((sym) => (
                  <SelectItem
                    key={sym.symbol}
                    value={sym.symbol}
                    className="text-white hover:bg-gray-700 focus:bg-gray-700"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{sym.label}</span>
                      <span className="text-xs text-gray-500">
                        {sym.category === 'commodity' && '🥇'}
                        {sym.category === 'crypto' && '₿'}
                        {sym.category === 'forex' && '💱'}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Interval Selector */}
            <Select value={selectedInterval} onValueChange={(v) => onIntervalChange(v as TimeInterval)}>
              <SelectTrigger className="w-[70px] sm:w-[80px] bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Interval" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                {INTERVALS.map((int) => (
                  <SelectItem
                    key={int.value}
                    value={int.value}
                    className="text-white hover:bg-gray-700 focus:bg-gray-700"
                  >
                    {int.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Refresh Button */}
            <Button
              variant="outline"
              size="icon"
              onClick={onRefresh}
              disabled={isRefreshing}
              className="bg-gray-800 border-gray-700 hover:bg-gray-700 text-white"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </Button>

            {/* API Status */}
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className={`bg-gray-800 border-gray-700 hover:bg-gray-700 ${
                    allApisConnected ? 'text-green-400' : 'text-yellow-400'
                  }`}
                >
                  {allApisConnected ? (
                    <div className="w-2 h-2 bg-green-400 rounded-full" />
                  ) : (
                    <AlertTriangle className="w-4 h-4" />
                  )}
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    API Configuration Status
                  </DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Check your API connection status
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 mt-4">
                  {/* TwelveData Status */}
                  <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-medium">TwelveData API</p>
                      <p className="text-xs text-gray-500">Market Data</p>
                    </div>
                    <Badge
                      variant={apiStatus.twelveData ? 'default' : 'destructive'}
                      className={apiStatus.twelveData ? 'bg-green-500/20 text-green-400' : ''}
                    >
                      {apiStatus.twelveData ? 'Connected' : 'Not Configured'}
                    </Badge>
                  </div>

                  {/* OpenRouter Status */}
                  <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-medium">OpenRouter API</p>
                      <p className="text-xs text-gray-500">AI Analysis</p>
                    </div>
                    <Badge
                      variant={apiStatus.openRouter ? 'default' : 'destructive'}
                      className={apiStatus.openRouter ? 'bg-green-500/20 text-green-400' : ''}
                    >
                      {apiStatus.openRouter ? 'Connected' : 'Not Configured'}
                    </Badge>
                  </div>

                  {/* Setup Instructions */}
                  {!allApisConnected && (
                    <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                      <p className="text-sm text-yellow-400 font-medium mb-2">Setup Required</p>
                      <ol className="text-xs text-yellow-300/80 space-y-1 list-decimal list-inside">
                        <li>Get free API key from <a href="https://twelvedata.com" target="_blank" rel="noopener noreferrer" className="underline">twelvedata.com</a></li>
                        <li>Get free API key from <a href="https://openrouter.ai" target="_blank" rel="noopener noreferrer" className="underline">openrouter.ai</a></li>
                        <li>Edit file: <code className="bg-gray-800 px-1 rounded">src/config/api.ts</code></li>
                        <li>Or use browser console:</li>
                      </ol>
                      <code className="block mt-2 p-2 bg-gray-800 rounded text-xs text-green-400 font-mono">
                        localStorage.setItem('TWELVEDATA_API_KEY', 'your_key')<br/>
                        localStorage.setItem('OPENROUTER_API_KEY', 'your_key')<br/>
                        location.reload()
                      </code>
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </header>
  );
}
